const jwt = require('jsonwebtoken');
const serect = 'token秘钥';
module.exports = (userinfo) => {
    const token = jwt.sign({
        user: userinfo.user
    }, serect, { expiresIn: '10m' });
    return token
}