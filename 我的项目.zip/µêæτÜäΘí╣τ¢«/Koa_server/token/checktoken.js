const jwt = require('jsonwebtoken');
const serect = 'token秘钥';
module.exports = (token) => {
    let decode = jwt.verify(`${token}`, serect, (err, decode) => {
        if (decode) {
            return {
                user:decode.user,
                iat: decode.iat,
                exp: decode.exp,
                msg: '有效的token'
            }
        } else if (err.name == 'TokenExpiredError') {
            return {
                iat: 1,
                exp: 0,
                msg: 'token过期'
            }
        } else if (err.name == 'JsonWebTokenError') {
            return {
                iat: 1,
                exp: 0,
                msg: '无效的token'
            }
        }
    });
    return decode
}