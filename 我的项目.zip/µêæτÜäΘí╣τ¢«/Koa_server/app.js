const koa = require('koa2');
const app = new koa();
const router = require('./router/index');
const bodyParser = require('koa-bodyparser');
const cors = require('koa2-cors');
const path = require('path');
const serve = require('koa-static');

const port = 3000;
const hostName = '127.0.0.1';
app.listen(port,hostName,()=>{
    console.log('server start success');
});

app.use(bodyParser()); //获取请求体的中间件
app.use(cors());        //cors跨域
app.use(serve(path.join(__dirname))); //静态资源服务

app.use(router.routes());
app.use(router.allowedMethods());