const mysql = require('mysql');
const pool = mysql.createPool({
    host: 'localhost',
    port: 3306,
    database: 'item',
    user: 'root',
    password: '123456'
});

function query(sql, callback) {
    pool.getConnection((err, connection) => {
        connection.query(sql, (err, rows) => {
            callback(err, rows);
            connection.release();
        })
    })
}
module.exports = {
    query
}