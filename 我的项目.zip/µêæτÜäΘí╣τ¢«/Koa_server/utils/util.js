// url地址 ? 传参 转换对象
function queryParams(params) {
    let s = params.indexOf('?');
    let s1 = 1 + s;
    let str = params.substr(s1);
    let arr = str.split('&');
    let obj = {};
    arr.forEach(item=>{
        let itemArr = item.split('=');
        obj[itemArr[0]] = itemArr[1]
    })
    return obj
}

module.exports = {
    queryParams
}