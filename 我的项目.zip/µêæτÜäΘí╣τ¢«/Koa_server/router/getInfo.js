const Router = require('koa-router');
const getInfo = new Router();
const checktoken = require('../token/checktoken');
const { query } = require('../utils/db');
let { queryParams } = require('../utils/util')

// 获取用户信息
getInfo.get('/userInfo', async (ctx) => {
    // 首先校验token,如果通过就往下走,不通过直接返回fasle
    let token = ctx.request.header.authorization;
    let { user, iat, exp } = checktoken(token);
    // if (!user || !iat > exp) {
    //     ctx.body = {
    //         code: 1,
    //         codeText: 'Error',
    //         message: '登录信息已过期'
    //     }
    //     return
    // }
    // 从数据库取得用户数据
    let result = await new Promise((resolve, reject) => {
        let sql = `select username,name,power,avatar from user where username='${user}'`;
        return query(sql, (err, result) => {
            if (err) { console.log(err) };
            resolve(result)
        })
    });
    ctx.body = result[0];
})

//获取所有的用户信息
getInfo.get('/all_user_info', async (ctx) => {
    // 首先校验token,如果通过就往下走,不通过直接返回fasle
    let token = ctx.request.header.authorization;
    let { user, iat, exp } = checktoken(token);
    if (!user || !iat > exp) {
        ctx.body = {
            code: 1,
            codeText: 'Error',
            message: '登录信息已过期'
        }
        return
    }
    let url = new URL(ctx.request.href);
    let { pageNo, limit } = queryParams(url.search);
    if (pageNo < 1) {
        pageNo = 1
    }
    // 从数据库取得用户数据
    let data = await new Promise((resolve, reject) => {
        let sql = `select username,name,power from user limit ${(pageNo - 1) * limit},${limit};`;
        return query(sql, (err, result) => {
            if (err) { console.log(err) };
            resolve(result)
        })
    });
    let rowAll = await new Promise((resolve, reject) => {
        let sql = `select count(username) 'rowAll' from user`;
        return query(sql, (err, result) => {
            if (err) { console.log(err) };
            resolve(result)
        })
    });
    let result = {
        data: data,
        rowTotal: rowAll[0].rowAll,
        pageTotal: Math.ceil(rowAll[0].rowAll / limit)
    };
    ctx.body = result;
})


module.exports = getInfo