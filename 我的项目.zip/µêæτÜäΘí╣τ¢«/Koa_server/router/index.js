const Router = require('koa-router');
const router = new Router();
const login = require('./login');
const getInfo = require('./getInfo');

login.get('/', async (ctx) => {
    ctx.response.body = '首页';
})

router.use('/login',login.routes(),login.allowedMethods());
router.use('/get',getInfo.routes(),getInfo.allowedMethods());

module.exports = router