const Router = require('koa-router');
const login = new Router();
const addtoken = require('../token/addtoken');
const checktoken = require('../token/checktoken');
const { query } = require('../utils/db');

// 登录接口
login.post('/', async (ctx) => {
    let { username, password } = ctx.request.body;
    // 从数据库取得数据
    let result = await new Promise((resolve, reject) => {
        let sql = `select * from user where username='${username}' and password='${password}'`;
        return query(sql, (err, data) => {
            if (err) { console.log(err) };
            resolve(data);
        })
    });
    if (result.length >= 1) {
        let token = addtoken({ user: `${username}` });
        ctx.response.body = {
            code: 0,
            codeText: '登录成功',
            token: token
        }
    } else {
        ctx.response.body = {
            code: 1,
            codeText: '登录失败'
        }
    }
});

// 验证是否登录
login.get('/isLogin', async (ctx) => {
    let token = ctx.request.header.authorization;
    if (!token) {
        ctx.body = {
            code: 1,
            codeText: 'Error'
        }
        return;
    }
    let { iat, exp } = checktoken(token);
    if (iat > exp) {
        ctx.body = {
            code: 1,
            codeText: 'Error'
        }
        return;
    }
    ctx.body = {
        code: 0,
        codeText: 'OK'
    }
});

module.exports = login