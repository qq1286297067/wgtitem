import Vue from 'vue'
import VueRouter from 'vue-router'
import { PrevLoading } from "../utils/loading"
import { Session } from '@/utils/storage';
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { isLogin, getUserInfo } from '../api/login'

// 解决vue-router跳转到同一路径报错
const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch(err => err)
}

const home = () => import('@/views/home')
const login = () => import('@/views/login')


Vue.use(VueRouter)


const routes = [{
    path: '/',
    component: home,
    redirect: '/home',
    children: [{
        path: '/home',
        component: () => import('./page/home')
    }, {
        path: '/set',
        redirect: '/set/setting',
        component: () => import('./page/set'),
        children: [{
            path: '/set/setting',
            component: () => import('./page/d')
        }, {
            path: '/set/d',
            component: () => import('./page/d')
        }]
    }, {
        path: '/c',
        component: () => import('./page/c')
    }, {
        path: '/d',
        component: () => import('./page/d')
    }]
}, {
    path: '/login',
    component: login
},];

const router = new VueRouter({
    mode: 'history',
    routes
})

// 加载 loading
PrevLoading.start();

// 延迟关闭进度条
export function delayNProgressDone(time = 300) {
    setTimeout(() => {
        NProgress.done();
    }, time);
}

// 验证是否登录
function isSignIn(next) {
    isLogin().then(res => {
        PrevLoading.done();
        if (res.code == 1 && res.codeText == 'Error') {
            new Vue().$alert('你还没有登录!', '请登录', {
                confirmButtonText: '确定',
                callback: () => {
                    Session.clear();
                    next({ path: '/login' })
                }
            })
        } else {
            next();
        }
    })
}

// 路由加载前
router.beforeEach((to, from, next) => {
    NProgress.configure({ showSpinner: false });
    if (to.path !== '/login') NProgress.start();
    let token = Session.get('token');
    if (to.path === '/login' && !token) {
        NProgress.start();
        next();
        delayNProgressDone();
    } else if (to.path === '/home' && !token) {
        isSignIn(next);
    } else {
        if (!token) {
            PrevLoading.done();
            NProgress.start();
            new Vue().$alert('你还没有登录!', '请登录', {
                confirmButtonText: '确定',
                callback: () => {
                    Session.clear();
                    next({ path: '/login' })
                }
            })
            Session.clear();
            delayNProgressDone();
        } else {
            next();
        }
    }
})
// 路由加载后
router.afterEach(() => {
    PrevLoading.done();
    delayNProgressDone();
})

// 导出路由
export default router