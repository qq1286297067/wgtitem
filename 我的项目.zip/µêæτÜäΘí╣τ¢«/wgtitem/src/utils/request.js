import axios from 'axios';
import { Session } from '@/utils/storage';
import { Message, MessageBox } from 'element-ui';

// 创建 axios 实例
const service = axios.create({
    baseURL: 'http://127.0.0.1:3000',
    timeout: 30000,
    headers: { 'Content-Type': 'application/json' }
});

// 添加请求拦截器
service.interceptors.request.use((config) => {
    // 在请求之前做些什么 token
    if (Session.get('token')) {
        config.headers.common['Authorization'] = `${Session.get('token').token}`;
    }
    return config
}, (error) => {
    // 对请求错误做些什么
    return Promise.reject(error);
});

// 添加响应拦截器
service.interceptors.response.use((response) => {
    // 对响应数据做些什么
    let res = response.data;
    // if (res.code && res.code != 0) {
    //     // 此处先空着
    //     return
    // }
    return res

}, (error) => {
    // 对响应错误做点什么
    if (error.message.indexOf('timeout') != -1) {
        Message.error('网络超时');
    } else if (error.message == 'Network Error') {
        Message.error('网络连接错误');
    } else {
        Message.error(error.message);
    }
    return Promise.reject(error);
});

// 导出 axios 实例
export default service;