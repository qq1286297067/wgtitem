import Vue from 'vue'
import Vuex from 'vuex'
import themeConfig from '@/store/modules/themeConfig'
import routerList from '@/store/modules/routerList'
import userInfo from '@/store/modules/userInfo'
Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    themeConfig,
    routerList,
    userInfo
  }
})
