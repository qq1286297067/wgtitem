
const routerList = {
    namespaced: true,
    state: {
        routerList: [{
            path: '/',
            children: [{
                path: '/home',
                meta: {  title: "首页" },
            }, {
                path: "/set",
                meta: {  title: "设置" },
                children: [{
                    path: '/set/setting',
                    meta: {  title: "设置" },
                },{
                    path: '/set/d',
                    meta: {  title: "里面的设置" },
                }]
            }, {
                path: "/c",
                meta: {  title: "客户" },
            }]
        }]
    },
    mutations: {
        // 设置路由数据
        getRouterList(state, data) {
            state.routerList = data
        }
    },
    actions: {
        // 设置路由数据
        setRouterList({ commit }, data) {
            commit('getRouterList', data)
        }
    }
}

export default routerList