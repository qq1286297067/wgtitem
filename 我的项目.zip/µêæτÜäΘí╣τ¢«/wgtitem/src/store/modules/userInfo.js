import { Session } from '@/utils/storage';
const userInfo = {
    namespaced: true,
    state: {
        userInfo: null
    },
    mutations: {
        // 设置 user 数据
        getUserInfo(state, data) {
            state.userInfo = data
        }
    },
    actions: {
        // 设置 user 数据
        // setUserInfo({ commit }, data) {
        //     commit('getUserInfo', data)
        // }
        async setUserInfo({ commit }, data) {
            if (data) {
                commit('getUserInfo', data);
            } else {
                if (Session.get('userInfo')) commit('getUserInfo', Session.get('userInfo'));
            }
        },
    }
}

export default userInfo