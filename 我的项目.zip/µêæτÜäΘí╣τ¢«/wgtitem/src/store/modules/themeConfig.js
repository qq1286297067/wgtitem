/**
 * 2020.05.28 by lyt 优化
 * 修改一下配置时，需要每次都清理 `window.localStorage` 浏览器永久缓存，配置才会生效
 */
const themeConfigModule = {
    namespaced: true,
    state: {
        themeConfig: {
            // 是否开启菜单水平折叠效果
            isCollapse: false,
            // 是否开启侧边栏 Logo
            isShowLogo: false,
            // 是否开启 Breadcrumb
            isBreadcrumb: true,
            // 是否开启 Breadcrumb 图标
            isBreadcrumbIcon: false,
            // 是否开启 Tagsview
            isTagsview: true,
        },
    },
    mutations: {
        // 设置布局配置
        getThemeConfig(state, data) {
            state.themeConfig = data;
        },
    },
    actions: {
        // 设置布局配置
        setThemeConfig({ commit }, data) {
            commit('getThemeConfig', data);
        },
    },
};

export default themeConfigModule;
