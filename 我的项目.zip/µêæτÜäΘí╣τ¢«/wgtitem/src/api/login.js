import service from '@/utils/request'

// 用户登录
function signIn(account, password) {
    return service({
        url: '/login',
        method: 'post',
        data: {
            username: account,
            password: password
        }
    })
}

// 是否登录
function isLogin() {
    return service.get('/login/isLogin').then(result => {
        return result
    })
}

function getUserInfo() {
    return service.get('/get/userinfo').then(result => {
        return result
    })
}


export {
    signIn,
    isLogin,
    getUserInfo
}