import service from '@/utils/request';

//取得所有的用户信息
async function queryAllUser(pageNo, limit) {
    let result;
    try {
        result = await service.get('/get/all_user_info', {
            params: {
                pageNo: pageNo,
                limit: limit
            }
        });
    } catch (err) {
        return err;
    }
    return result;
}

export {
    queryAllUser
}