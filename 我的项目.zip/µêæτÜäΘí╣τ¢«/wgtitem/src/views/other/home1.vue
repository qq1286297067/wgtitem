<template>
  <div class="home-container">
    <!-- 左边侧边栏 -->
    <div class="sidebar-container" :class="{ switchWidth: hide }">
      <div class="sidebar-logo-container">
        <div class="sidebar-logo-link">
          <h1></h1>
        </div>
      </div>
      <el-menu
        background-color="#304156"
        text-color="#bfcbd9"
        :collapse="is_collapse"
        :default-active="activeIndex()"
        :collapse-transition="false"
        router
      >
        <el-menu-item index="/home">
          <i class="el-icon-s-home"></i>
          <span slot="title" class="_left">首页</span>
        </el-menu-item>
        <el-submenu index="">
          <template slot="title">
            <i class="el-icon-s-cooperation"></i>
            <span slot="title" class="_left">系统管理</span>
          </template>
          <el-menu-item index="/user_setting">
            <i class="el-icon-user-solid"></i>
            <span slot="title" class="_left">用户管理</span>
          </el-menu-item>
        </el-submenu>
        <el-menu-item index="2">
          <i class="el-icon-s-cooperation"></i>
          <span slot="title" class="_left">系统设置</span>
        </el-menu-item>
        <el-menu-item index="3">
          <i class="el-icon-s-home"></i>
          <span slot="title" class="_left">首页2</span>
        </el-menu-item>
        <el-menu-item index="4">
          <i class="el-icon-s-home"></i>
          <span slot="title" class="_left">首页3</span>
        </el-menu-item>
        <el-menu-item index="5">
          <i class="el-icon-s-home"></i>
          <span slot="title" class="_left">首页4</span>
        </el-menu-item>
      </el-menu>
    </div>
    <!-- 主体 -->
    <div class="main-container" :class="{ switchLeft: hide }">
      <!-- 主体头部 -->
      <div class="main-container-header" :class="{ switchLeft: hide }">
        <!-- 隐藏切换按钮 -->
        <div class="switch-button" @click="handleSidebar">
          <i class="el-icon-s-fold" v-if="icon_active"></i>
          <i class="el-icon-s-unfold" v-else></i>
        </div>
        <el-breadcrumb>
          <el-breadcrumb-item
            v-for="(item, index) in activeTitle()"
            :key="index"
            >{{ item }}</el-breadcrumb-item
          >
        </el-breadcrumb>
        <div class="right-menu">
          <div class="switch-screen-size" @click="toggleFullScreen">
            <el-tooltip
              class="item"
              effect="dark"
              content="全屏缩放"
              placement="bottom-start"
            >
              <i class="el-icon-full-screen"></i>
            </el-tooltip>
          </div>
          <el-dropdown @command="changePath">
            <div class="avatar-container el-dropdown-link">
              <div class="user-avatar">
                <el-avatar shape="square" icon="el-icon-user-solid"></el-avatar>
              </div>
              <div class="user-name">{{ $store.state.userInfo.name }}</div>
              <i class="el-icon-caret-bottom"></i>
            </div>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item command="user_info">个人中心</el-dropdown-item>
              <el-dropdown-item command="change_password"
                >修改密码</el-dropdown-item
              >
              <el-dropdown-item command="sign_out" divided
                >退出登录</el-dropdown-item
              >
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
      <!-- 主体内容区域 -->
      <div class="app-main">
        <router-view />
      </div>
    </div>
  </div>
</template>

<script>
import { getUserInfo } from "@/api/login";
export default {
  data() {
    return {
      hide: false,
      icon_active: true,
      is_collapse: false,
    };
  },
  created() {
    getUserInfo().then((result) => {
      this.$store.commit("changeUserInfo", result);
    });
  },
  methods: {
    handleSidebar() {
      this.hide ? (this.hide = false) : (this.hide = true);
      this.icon_active = !this.icon_active;
      this.is_collapse = !this.is_collapse;
    },
    activeIndex() {
      let nowUrl = location.href;
      if (nowUrl.includes("/home")) return "/home";
      if (nowUrl.includes("/user_setting")) return "/user_setting";
    },
    activeTitle() {
      let nowUrl = location.href;
      if (nowUrl.includes("/home")) return ["首页"];
      if (nowUrl.includes("/user_info")) return ["个人中心"];
      if (nowUrl.includes("/user_setting")) return ["系统管理", "用户管理"];
    },
    toggleFullScreen() {
      if (
        !document.fullscreenElement &&
        !document.msFullscreenElement &&
        !document.mozFullScreenElement &&
        !document.webkitFullscreenElement
      ) {
        var docElm = document.documentElement;
        if (docElm.requestFullscreen) {
          docElm.requestFullscreen();
        } else if (docElm.msRequestFullscreen) {
          //IE
          docElm = document.body; //overwrite the element (for IE)
          docElm.msRequestFullscreen();
        } else if (docElm.mozRequestFullScreen) {
          //火狐
          docElm.mozRequestFullScreen();
        } else if (docElm.webkitRequestFullScreen) {
          //谷歌
          docElm.webkitRequestFullScreen();
        }
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if (document.msExitFullscreen) {
          document.msExitFullscreen();
        } else if (document.mozCancelFullScreen) {
          document.mozCancelFullScreen();
        } else if (document.webkitCancelFullScreen) {
          document.webkitCancelFullScreen();
        }
      }
    },
    changePath(path) {
      if (path == "user_info") {
        this.$router.push(path);
        return;
      }
      if (path == "sign_out") {
        this.$confirm("你确定要退出登录吗？", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          closeOnClickModal: false,
          type: "warning",
          lockScroll: false,
        })
          .then(() => {
            localStorage.removeItem("token");
            this.$router.push("/login");
          })
          .catch(() => {});
      }
    },
  },
};
</script>

<style lang="less">
div,
span,
i {
  outline: none;
}
.home-container {
  height: 100%;
}
.sidebar-container {
  min-height: 100%;
  width: 210px;
  background-color: #304156;
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  z-index: 1001;
  transition: width 0.28s;

  .sidebar-logo-container {
    position: relative;
    width: 100%;
    height: 50px;
    background-color: #2b2f3a;
    color: #fff;

    .sidebar-logo-link {
      cursor: pointer;
      h1 {
        text-align: center;
        line-height: 50px;
      }
    }
  }
}
.switchWidth.sidebar-container {
  width: 64px;
}

.main-container {
  min-height: 100%;
  width: calc(100% - 210px);
  margin-left: 210px;
  transition: all 0.28s;

  .main-container-header {
    position: fixed;
    top: 0;
    right: 0;
    width: calc(100% - 210px);
    height: 50px;
    background-color: #fff;
    box-shadow: 0 1px 4px rgba(0, 21, 41 / 8%, 0.12);
    transition: width 0.28s;
    z-index: 1001;

    .switch-button {
      cursor: pointer;
      font-size: 20px;
      width: 50px;
      height: 50px;
      line-height: 50px;
      text-align: center;
      transition: background-color 0.3s;
      float: left;
      margin-right: 10px;
    }
    :hover.switch-button {
      background-color: rgba(180, 180, 180, 0.1);
    }
    .el-breadcrumb {
      line-height: 50px;
      float: left;
      .el-breadcrumb__inner {
        color: #97a8be;
      }
    }
    .right-menu {
      float: right;
      height: 50px;
      display: flex;
      align-items: center;

      .switch-screen-size {
        height: 50px;
        font-size: 16px;
        cursor: pointer;
        .el-tooltip {
          line-height: 50px;
          padding: 0 10px;
        }
        :hover.el-tooltip {
          background-color: rgba(180, 180, 180, 0.1);
        }
      }
      .avatar-container {
        position: relative;
        height: 50px;
        display: flex;
        align-items: center;
        margin-right: 30px;
        padding: 0 7px;
        cursor: pointer;
        transition: background-color 0.3s;

        .user-avatar {
          margin-right: 5px;
        }
        .user-name {
          font-size: 14px;
          color: #444444;
        }
        i.el-icon-caret-bottom {
          margin-top: 6px;
          margin-left: 3px;
        }
      }
      :hover.avatar-container {
        background-color: rgba(180, 180, 180, 0.1);
      }
    }
  }
  .app-main {
    padding-top: 50px;
    width: 100%;
    height: 100%;
  }
}
.switchLeft {
  margin-left: 64px;
  width: calc(100% - 64px) !important;
}

.el-menu {
  border: none;
}

._left {
  margin-left: 8px;
}
</style>