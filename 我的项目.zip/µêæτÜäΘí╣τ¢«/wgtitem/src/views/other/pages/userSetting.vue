<template>
  <div class="user-setting-container">
    <div class="button-wrapper">
      <el-button type="primary" size="mini" @click="dialogVisible">
        <i class="el-icon-plus"></i>
        新增
      </el-button>
    </div>
    <div class="table-wrapper">
      <el-table :data="tableData" border size="mini" style="">
        <el-table-column
          prop="username"
          label="账号"
          width="100"
          align="center"
        >
        </el-table-column>
        <el-table-column prop="name" label="姓名" width="100" align="center">
        </el-table-column>
        <el-table-column prop="" label="手机号" width="100" align="center">
        </el-table-column>
        <el-table-column prop="" label="职位" width="100" align="center">
        </el-table-column>
        <el-table-column prop="" label="其他" align="center"> </el-table-column>
        <el-table-column prop="power" label="权限" width="100" align="center">
        </el-table-column>
        <el-table-column label="操作" width="150" align="center">
          <el-link type="primary">编辑</el-link>
          <el-link type="danger" style="margin-left: 15px">删除</el-link>
        </el-table-column>
      </el-table>
    </div>
    <my-pagination
      :totals="rowTotal"
      :pageSize="pageSize"
      @size-change="handleSizeChange"
    ></my-pagination>
    <el-dialog title="添加用户" :visible.sync="dialog.is_visible" width="40%">
      <el-form label-width="80px" size="small">
        <el-form-item label="账号">
          <el-input></el-input>
        </el-form-item>
        <el-form-item label="姓名">
          <el-input></el-input>
        </el-form-item>
        <el-form-item label="手机号">
          <el-input></el-input>
        </el-form-item>
        <el-form-item label="职位">
          <el-input></el-input>
        </el-form-item>
        <el-form-item label="其他">
          <el-input></el-input>
        </el-form-item>
        <el-form-item label="权限">
          <el-input></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialog.is_visible = false">取消</el-button>
        <el-button type="primary">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { queryAllUser } from "@/api/home.js";
import myPagination from "@/components/my-pagination";
export default {
  data() {
    return {
      tableData: [],
      pageTotal: 0,
      rowTotal: 0,
      limit: 10,
      pageSize: 10,
      pageNo: 1,
      dialog: {
        is_visible: false,
      },
    };
  },
  components: {
    myPagination,
  },
  methods: {
    handleSizeChange(pageNo) {
      this.pageNo = pageNo;
      this.queryData(this.pageNo, this.limit);
    },
    //从服务器拿数据，异步
    async queryData(pageNo, limit) {
      try {
        let result = await queryAllUser(pageNo, limit);
        if (result.code == 1 && result.message == "登录信息已过期") {
          this.$message.error("获取数据失败，请刷新页面");
        }
        let { data, pageTotal, rowTotal } = result;
        this.tableData = data;
        this.pageTotal = pageTotal;
        this.rowTotal = rowTotal;
      } catch (err) {
        this.$message.error("获取数据失败");
      }
    },
    dialogVisible() {
      this.dialog.is_visible = true;
    },
  },
  created() {
    this.pageNo = parseInt(sessionStorage.getItem("pagination_pageNo")) || 1;
    this.queryData(this.pageNo, this.limit);
  },
};
</script>

<style lang="less">
.user-setting-container {
  position: relative;
  padding: 32px;
  height: calc(100% - 50px);
  background-color: #fff;
  .button-wrapper {
    margin-bottom: 15px;
  }
  .table-wrapper {
    .el-link {
      user-select: none;
    }
  }
  .pagination {
    margin-top: 20px;
  }
}
</style>