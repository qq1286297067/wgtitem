<template>
  <div class="home-container">
    <div class="sidebar-container" :class="{ 'layout-width': hide }">
      <div class="sidebar-container-logo"></div>
      <el-menu
        background-color="#304156"
        text-color="#bfcbd9"
        :default-active="activeIndex()"
        :collapse="is_collapse"
        :collapse-transition="false"
        router
      >
        <el-menu-item index="/home">
          <i class="el-icon-s-home"></i>
          <span slot="title" class="_left">首页</span>
        </el-menu-item>
        <el-submenu index="">
          <template slot="title">
            <i class="el-icon-s-cooperation"></i>
            <span slot="title" class="_left">系统管理</span>
          </template>
          <el-menu-item index="/user_setting">
            <i class="el-icon-user-solid"></i>
            <span slot="title" class="_left">用户管理</span>
          </el-menu-item>
        </el-submenu>
        <el-menu-item index="2">
          <i class="el-icon-s-cooperation"></i>
          <span slot="title" class="_left">系统设置</span>
        </el-menu-item>
        <el-menu-item index="3">
          <i class="el-icon-s-home"></i>
          <span slot="title" class="_left">首页2</span>
        </el-menu-item>
        <el-menu-item index="4">
          <i class="el-icon-s-home"></i>
          <span slot="title" class="_left">首页3</span>
        </el-menu-item>
        <el-menu-item index="5">
          <i class="el-icon-s-home"></i>
          <span slot="title" class="_left">首页4</span>
        </el-menu-item>
      </el-menu>
    </div>
    <div class="main-container" :class="{ 'layout-width': hide }">
      <div class="main-container-header">
        <div class="switch-container-button" @click="switchWidth">
          <i class="el-icon-s-fold" v-if="hide"></i>
          <i class="el-icon-s-unfold" v-else></i>
        </div>
        <el-breadcrumb>
          <el-breadcrumb-item
            v-for="(item, index) in activeTitle()"
            :key="index"
            >{{ item }}</el-breadcrumb-item
          >
        </el-breadcrumb>
        <div class="right-menu">
          <div class="switch-screen-size" @click="toggleFullScreen">
            <el-tooltip
              class="item"
              effect="dark"
              content="全屏缩放"
              placement="bottom-start"
            >
              <i class="el-icon-full-screen"></i>
            </el-tooltip>
          </div>
          <el-dropdown @command="changePath">
            <div class="avatar-container el-dropdown-link">
              <div class="user-avatar">
                <el-avatar shape="square" icon="el-icon-user-solid"></el-avatar>
              </div>
              <div class="user-name">{{ $store.state.userInfo.name }}</div>
              <i class="el-icon-caret-bottom"></i>
            </div>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item command="user_info">个人中心</el-dropdown-item>
              <el-dropdown-item command="change_password"
                >修改密码</el-dropdown-item
              >
              <el-dropdown-item command="sign_out" divided
                >退出登录</el-dropdown-item
              >
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
      <div class="main-container-body">
        <router-view/>
      </div>
    </div>
  </div>
</template>

<script>
import { getUserInfo } from "@/api/login";
export default {
  data() {
    return {
      hide: false,
      is_collapse: false,
    };
  },
  methods: {
    switchWidth() {
      this.hide = this.hide ? false : true;
      this.is_collapse = this.hide ? true : false;
    },
    activeIndex() {
      let nowUrl = location.href;
      if (nowUrl.includes("/home")) return "/home";
      if (nowUrl.includes("/user_setting")) return "/user_setting";
    },
    activeTitle() {
      let nowUrl = location.href;
      if (nowUrl.includes("/home")) return ["首页"];
      if (nowUrl.includes("/user_info")) return ["个人中心"];
      if (nowUrl.includes("/user_setting")) return ["系统管理", "用户管理"];
    },
    toggleFullScreen() {
      if (
        !document.fullscreenElement &&
        !document.msFullscreenElement &&
        !document.mozFullScreenElement &&
        !document.webkitFullscreenElement
      ) {
        var docElm = document.documentElement;
        if (docElm.requestFullscreen) {
          docElm.requestFullscreen();
        } else if (docElm.msRequestFullscreen) {
          //IE
          docElm = document.body; //overwrite the element (for IE)
          docElm.msRequestFullscreen();
        } else if (docElm.mozRequestFullScreen) {
          //火狐
          docElm.mozRequestFullScreen();
        } else if (docElm.webkitRequestFullScreen) {
          //谷歌
          docElm.webkitRequestFullScreen();
        }
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if (document.msExitFullscreen) {
          document.msExitFullscreen();
        } else if (document.mozCancelFullScreen) {
          document.mozCancelFullScreen();
        } else if (document.webkitCancelFullScreen) {
          document.webkitCancelFullScreen();
        }
      }
    },
    changePath(path) {
      if (path == "user_info") {
        this.$router.push(path);
        return;
      }
      if (path == "sign_out") {
        this.$confirm("你确定要退出登录吗？", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          closeOnClickModal: false,
          type: "warning",
        })
          .then(() => {
            localStorage.removeItem("token");
            this.$router.push("/login");
          })
          .catch(() => {});
      }
    },
  },
  created() {
    getUserInfo().then((result) => {
      this.$store.commit("changeUserInfo", result);
    });
  },
};
</script>

<style lang="less">
div,
span,
i {
  outline: none;
}
// 动态切换宽度
.layout-width.sidebar-container {
  width: 64px;
}
// 动态切换宽度
.layout-width.main-container {
  width: calc(100% - 64px);
}
.home-container {
  display: flex;
  height: 100%;
}
.sidebar-container {
  width: 210px;
  height: 100%;
  background-color: #304156;
  overflow: hidden;
  transition: all 0.28s;
  .el-menu {
    border: none;
  }
  .sidebar-container-logo {
    position: relative;
    width: 100%;
    height: 50px;
    background-color: #2b2f3a;
    color: #fff;
  }
}
.main-container {
  position: relative;
  width: calc(100% - 210px);
  height: 100%;
  transition: all 0.28s;
  .main-container-header {
    position: absolute;
    top: 0;
    right: 0;
    z-index: 999;
    width: 100%;
    height: 50px;
    background-color: #fff;
    box-shadow: 0 1px 4px rgba(0, 21, 41 / 8%, 0.12);
    .switch-container-button {
      cursor: pointer;
      font-size: 20px;
      width: 50px;
      height: 50px;
      line-height: 50px;
      text-align: center;
      transition: background-color 0.3s;
      float: left;
      margin-right: 10px;
    }
    :hover.switch-container-button {
      background-color: rgba(180, 180, 180, 0.1);
    }
    .el-breadcrumb {
      line-height: 50px;
      float: left;
      user-select: none;
      .el-breadcrumb__inner {
        color: #97a8be;
      }
    }
    .right-menu {
      float: right;
      height: 50px;
      display: flex;
      align-items: center;

      .switch-screen-size {
        height: 50px;
        font-size: 16px;
        cursor: pointer;
        .el-tooltip {
          line-height: 50px;
          padding: 0 10px;
        }
        :hover.el-tooltip {
          background-color: rgba(180, 180, 180, 0.1);
        }
      }
      .avatar-container {
        position: relative;
        height: 50px;
        display: flex;
        align-items: center;
        margin-right: 30px;
        padding: 0 7px;
        cursor: pointer;
        transition: background-color 0.3s;

        .user-avatar {
          margin-right: 5px;
        }
        .user-name {
          font-size: 14px;
          color: #444444;
        }
        i.el-icon-caret-bottom {
          margin-top: 6px;
          margin-left: 3px;
        }
      }
      :hover.avatar-container {
        background-color: rgba(180, 180, 180, 0.1);
      }
    }
  }
  .main-container-body {
    position: relative;
    height: calc(100% - 50px);
    margin-top: 50px;
    overflow: auto;
    background-color: #f0f2f5;
  }
}
</style>