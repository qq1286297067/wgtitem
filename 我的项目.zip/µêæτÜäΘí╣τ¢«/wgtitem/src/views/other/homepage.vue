<template>
  <div class="dashboard-container">
    <div class="my-state-wrapper">
      <el-row :gutter="20">
        <el-col :span="8">
          <div class="card-panel">
            <div class="card-panel-icon-wrapper item2">
              <i class="el-icon-s-custom"></i>
            </div>
            <div class="card-panel-description">
              <!-- <div class="card-panel-text">当月BUG量</div>
              <div class="card-panel-num">0</div> -->
            </div>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="card-panel">
            <div class="card-panel-icon-wrapper">
              <i class="el-icon-s-promotion"></i>
            </div>
            <div class="card-panel-description"></div>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="card-panel">
            <div class="card-panel-icon-wrapper item3">
              <i class="el-icon-s-promotion"></i>
            </div>
            <div class="card-panel-description"></div>
          </div>
        </el-col>
      </el-row>
    </div>
    <div class="dataTable-wrapper">
      <el-row>
        <el-col :span="24">
          <div class="echarts-table"></div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
export default {
  methods: {},
};
</script>

<style lang="less">
.dashboard-container {
  padding: 32px;
  background-color: #f0f2f5;

  .card-panel {
    height: 110px;
    // cursor: pointer;
    font-size: 12px;
    position: relative;
    overflow: hidden;
    color: #666;
    background: #fff;
    border-color: rgba(0, 0, 0, 0.05);

    &:hover .card-panel-icon-wrapper {
      background-color: #36a3f7;
      color: #fff;
    }
    &:hover .item2 {
      background-color: #40c9c6;
      color: #fff;
    }
    &:hover .item3 {
      background-color: #e6a23c;
      color: #fff;
    }

    .card-panel-icon-wrapper {
      float: left;
      width: 94px;
      height: 94px;
      margin: 8px 0 0 8px;
      border-radius: 5px;
      transition: all 0.38s ease-out;
      text-align: center;
      color: #36a3f7;

      i.el-icon-s-promotion {
        margin-top: 13px;
        font-size: 60px;
      }
      i.el-icon-s-custom {
        margin-top: 13px;
        font-size: 60px;
      }
    }
    .item2 {
      color: #40c9c6;
    }
    .item3 {
      color: #e6a23c;
    }
    .card-panel-description {
      float: right;
      font-weight: 700;
      margin: 25px 40px 0 0;
      font-size: 16px;
      color: rgba(0, 0, 0, 0.45);
      .card-panel-num {
        margin-top: 8px;
      }
    }
  }

  .dataTable-wrapper {
    margin-top: 35px;
    background: #fff;
    // -webkit-box-shadow: 4px 4px 40px rgb(0 0 0 / 5%);
    // box-shadow: 4px 4px 40px rgb(0 0 0 / 5%);
    box-shadow: 0px 1px 1px #ccc;
    border-color: rgba(0, 0, 0, 0.05);
    .echarts-table {
      height: 500px;
      // background-color: lightblue;
    }
  }
}
</style>