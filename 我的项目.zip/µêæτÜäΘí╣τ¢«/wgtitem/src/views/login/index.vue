<template>
  <div class="login_container">
    <div class="login_box">
      <h1>WGT后台管理系统</h1>
      <el-form :model="userdata">
        <el-form-item>
          <el-input
            placeholder="请输入账号"
            prefix-icon="el-icon-user"
            clearable
            maxlength="16"
            v-model.trim="userdata.account"
          ></el-input>
        </el-form-item>
        <el-form-item>
          <el-input
            placeholder="请输入密码"
            prefix-icon="el-icon-unlock"
            show-password
            clearable
            maxlength="16"
            v-model.trim="userdata.password"
          ></el-input>
        </el-form-item>
        <transition name="fade">
          <div class="error_message" v-show="isError">{{ err_message }}</div>
        </transition>
        <el-form-item>
          <el-checkbox label="记住我" v-model="ischeck"></el-checkbox>
        </el-form-item>
        <el-button type="primary" style="width: 100%" @click="submit"
          >登录</el-button
        >
      </el-form>
    </div>
  </div>
</template>

<script>
import { signIn, getUserInfo } from "@/api/login";
import { Local, Session } from "@/utils/storage";
import { PrevLoading } from "@/utils/loading";
export default {
  data() {
    return {
      userdata: {
        account: "",
        password: "",
      },
      ischeck: false,
      err_message: "",
      isError: false,
    };
  },
  created() {
    this.userdata.account = Local.get("userdata").account;
    this.userdata.password = Local.get("userdata").password;
    this.ischeck = localStorage.getItem("ischeck") === "true";
  },
  methods: {
    checkAccount() {
      let reg = /^[a-zA-Z0-9_-]{3,16}$/;
      return reg.test(this.userdata.account);
    },
    checkPassword() {
      let reg = /^[a-zA-Z0-9_-]{6,18}$/;
      return reg.test(this.userdata.password);
    },
    memorizeUser() {
      Local.set("userdata", this.userdata);
      Local.set("ischeck", this.ischeck);
    },
    removeUser() {
      Local.remove("userdata");
    },
    submit() {
      if (this.ischeck) {
        this.memorizeUser();
      } else {
        this.removeUser();
      }
      if (!this.checkAccount() || !this.checkPassword()) {
        this.err_message = "请输入正确的账号和密码";
        this.isError = true;
        return;
      }
      signIn(this.userdata.account, this.userdata.password).then(
        async (result) => {
          if (result.code === 0 && result.codeText === "登录成功") {
            // 存储 token 到浏览器缓存
            Session.set("token", { token: result.token });
            // 请求拿到用户信息
            let userInfo = await new Promise((resolve) => {
              getUserInfo().then((res) => {
                resolve(res);
              });
            });
            // 存储用户信息到浏览器缓存
            Session.set("userInfo", userInfo);
            // 存储用户信息到vuex
            this.$store.dispatch("userInfo/setUserInfo", userInfo);
            PrevLoading.start();
            setTimeout(() => {
              this.$router.push("/home");
            }, 1000);
          } else {
            this.err_message = "请输入正确的账号和密码";
            this.isError = true;
          }
        }
      );
    },
  },
};
</script>

<style lang="less">
.login_container {
  width: 100%;
  height: 100%;
  background-image: url("../../assets/static/images/login-background1.png");
  background-repeat: no-repeat;
  background-size: cover;
  overflow: hidden;
  .login_box {
    width: 400px;
    height: 335px;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    padding: 25px;
    background-color: #fff;
    border-radius: 5px;
    box-sizing: border-box;
    h1 {
      color: #707070;
      font-weight: 700;
      font-size: 19px;
      text-align: center;
      letter-spacing: 1px;
      margin-bottom: 30px;
    }
  }
}
.error_message {
  position: absolute;
  left: 25px;
  top: 187px;
  color: #f56c6c;
}
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}
</style>