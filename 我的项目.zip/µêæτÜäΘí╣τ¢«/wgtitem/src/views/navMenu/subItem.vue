<template>
  <div>
    <template v-for="val in chil">
      <el-submenu
        :index="val.path"
        :key="val.path"
        v-if="val.children && val.children.length > 0"
      >
        <template slot="title">
          <i :class="val.meta.icon"></i>
          <span>{{ val.meta.title }}</span>
        </template>
        <!-- 递归调用当前组件 -->
        <sub-item :chil="val.children" />
      </el-submenu>
      <el-menu-item :index="val.path" :key="val.path" v-else>
        <i :class="val.meta.icon ? val.meta.icon : ''"></i>
        <span>{{ val.meta.title }}</span>
      </el-menu-item>
    </template>
  </div>
</template>

<script>
export default {
  name: "subItem",
  props: {
    chil: {
      type: Array,
      default() {
        return [];
      },
    },
  },
};
</script>

<style>
</style>