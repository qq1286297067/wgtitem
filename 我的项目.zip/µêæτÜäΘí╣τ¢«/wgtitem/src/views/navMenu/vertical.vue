<template>
  <el-menu
    router
    background-color="#545c64"
    :default-active="defaultActive"
    :collapse="setIsCollapse"
    :unique-opened="isUniqueOpened"
    :collapse-transition="false"
  >
    <template v-for="val in menuList">
      <el-submenu
        :index="val.path"
        v-if="val.children && val.children.length > 0"
        :key="val.path"
      >
        <template slot="title">
          <i :class="val.meta.icon ? val.meta.icon : ''"></i>
          <span>{{ val.meta.title }}</span>
        </template>
        <SubItem :chil="val.children"></SubItem>
      </el-submenu>
      <el-menu-item :index="val.path" :key="val.path" v-else>
        <i :class="val.meta.icon ? val.meta.icon : ''"></i>
        <span>{{ val.meta.title }}</span>
      </el-menu-item>
    </template>
  </el-menu>
</template>

<script>
import SubItem from "@/views/navMenu/subItem.vue";
export default {
  name: "navMenuVertical",
  components: { SubItem },
  props: {
    menuList: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {
      defaultActive: this.$route.path,
      isUniqueOpened: true,
    };
  },
  computed: {
    // 获取布局配置信息
    getThemeConfig() {
      return this.$store.state.themeConfig.themeConfig;
    },
    // 设置左侧菜单是否展开/收起
    setIsCollapse() {
      return this.$store.state.themeConfig.themeConfig.isCollapse;
    },
  },
  watch: {
    // 监听路由的变化
    $route: {
      handler(to) {
        this.defaultActive = to.path;
      },
      deep: true,
    },
  },
};
</script>

<style>
</style>