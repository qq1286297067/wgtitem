<template>
  <el-container class="layout-container">
    <!-- 侧标栏 -->
    <el-aside
      class="layout-aside"
      style="width: 220px"
      :class="
        getThemeConfig.isCollapse
          ? 'layout-aside-width64'
          : 'layout-aside-width-default'
      "
    >
      <el-scrollbar>
        <NavMenuVertical :menuList="getRouterList"></NavMenuVertical>
      </el-scrollbar>
    </el-aside>
    <!-- 主体 -->
    <el-main class="layout-main">
      <el-scrollbar>
        <el-header class="layout-header">
          <NavBars />
        </el-header>
        <el-main class="layout-main__main">
          <router-view />
        </el-main>
      </el-scrollbar>
    </el-main>
  </el-container>
</template>

<script>
import NavMenuVertical from "@/views/navMenu/vertical.vue";
import NavBars from "@/views/navBars";
// import { getUserInfo } from "@/api/login";
export default {
  data() {
    return {};
  },
  components: {
    NavMenuVertical,
    NavBars,
  },
  computed: {
    // 从 vuex 获取配置信息
    getThemeConfig() {
      return this.$store.state.themeConfig.themeConfig;
    },
    // 从 vuex 获取路由信息
    getRouterList() {
      return this.$store.state.routerList.routerList[0].children;
    },
  },
  mounted() {
    // // 请求用户信息更新到vuex
    // getUserInfo().then((res) => {
    //   this.$store.commit('userInfo/getUserInfo',res)
    // });
  },
};
</script>

<style lang="less">
</style>