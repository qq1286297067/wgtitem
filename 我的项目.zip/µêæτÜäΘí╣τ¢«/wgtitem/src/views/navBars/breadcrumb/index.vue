<template>
  <div class="layout-navbars-breadcrumb-box">
    <Breadcrumb />
    <User />
  </div>
</template>

<script>
import Breadcrumb from "./breadcrumb.vue";
import User from "./user.vue";
export default {
  name: "breadcrumbBox",
  components: { Breadcrumb, User },
  data() {
    return {};
  },
};
</script>

<style lang="less" scoped>
.layout-navbars-breadcrumb-box {
  height: 50px;
  display: flex;
  align-items: center;
  padding-right: 15px;
  background: #fff;
  overflow: hidden;
  border-bottom: 1px solid #f1f2f3;
}
</style>