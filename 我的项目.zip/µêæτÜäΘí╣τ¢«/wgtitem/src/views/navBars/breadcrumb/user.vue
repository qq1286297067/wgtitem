<template>
  <div class="layout-navbars-user">
    <div class="layout-navbars-user-item" @click="onSearchClick">
      <i class="el-icon-search"></i>
    </div>
    <div class="layout-navbars-user-item">
      <el-popover placement="bottom" :width="300">
        <div class="layout-navbars-user-news">
          <div class="header-news">header</div>
          <div class="content-news">content</div>
          <div class="footer-news">footer</div>
        </div>
        <el-badge is-dot class="item" slot="reference">
          <i class="el-icon-bell"></i>
        </el-badge>
      </el-popover>
    </div>
    <div class="layout-navbars-user-item">
      {{ userInfo.name + '正在做' }}
    </div>
    <Search ref="searchRef" />
  </div>
</template>

<script>
import Search from "./search.vue";
import { Session } from "@/utils/storage";
export default {
  data() {
    return {};
  },
  components: {
    Search,
  },
  computed: {
    userInfo() {
      if (this.$store.state.userInfo.userInfo) {
        return this.$store.state.userInfo.userInfo;
      } else {
        return Session.get("userInfo");
      }
    },
  },
  methods: {
    // 搜索点击
    onSearchClick() {
      this.$refs.searchRef.openSearch();
    },
  },
  mounted() {
    console.log(this.$store.state.userInfo);
    console.log(Session.get("userInfo"));
  },
};
</script>

<style lang="less" scoped>
.layout-navbars-user {
  display: flex;
  height: inherit;
  justify-content: flex-end;
  align-items: center;
  .layout-navbars-user-item {
    height: 50px;
    color: #606266;
    cursor: pointer;
    padding: 0 10px;
    line-height: 50px;
    transition: all 0.3s;
    .item {
      display: inline;
    }
    .layout-navbars-user-news {
    }
  }
  .layout-navbars-user-item:hover {
    background-color: rgba(80, 80, 80, 0.1);
  }
}
</style>