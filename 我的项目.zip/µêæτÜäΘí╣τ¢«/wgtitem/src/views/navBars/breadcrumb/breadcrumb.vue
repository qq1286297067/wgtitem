<template>
  <div class="layout-navbars-breadcrumb">
    <i
      class="layout-navbars-breadcrumb-icon"
      :class="getThemeConfig.isCollapse ? 'el-icon-s-unfold' : 'el-icon-s-fold'"
      @click="onThemeConfigChange"
    ></i>
    <el-breadcrumb separator="/">
      <el-breadcrumb-item
        v-for="item in breadcrumbList"
        :key="item.path"
        :to="{ path: item.path }"
        >{{ item.meta.title }}
      </el-breadcrumb-item>
    </el-breadcrumb>
  </div>
</template>

<script>
export default {
  name: "breadcrumb",
  components: {},
  data() {
    return {
      breadcrumbList: [],
      routeSplit: [],
      routeSplitFirst: "",
      routeSplitIndex: 1,
    };
  },
  methods: {
    // breadcrumb icon 点击菜单展开与收起
    onThemeConfigChange() {
      this.$store.state.themeConfig.themeConfig.isCollapse =
        !this.$store.state.themeConfig.themeConfig.isCollapse;
    },
    // 递归设置 breadcrumb
    getBreadcrumbList(arr) {
      arr.map((item) => {
        this.routeSplit.map((value, index, arrs) => {
          if (this.routeSplitFirst === item.path) {
            this.routeSplitFirst += `/${arrs[this.routeSplitIndex]}`;
            this.breadcrumbList.push(item);
            this.routeSplitIndex++;
            if (item.children) this.getBreadcrumbList(item.children);
          }
        });
      });
    },
    // 当前路由分割处理
    initRouteList(path) {
      this.breadcrumbList = [
        {
          path: "/",
          meta: { icon: "el-icon-s-tools", title: "首页" },
        },
      ];
      this.routeSplit = path.split("/");
      this.routeSplit.shift();
      this.routeSplitFirst = `/${this.routeSplit[0]}`;
      this.routeSplitIndex = 1;
      this.getBreadcrumbList(
        this.$store.state.routerList.routerList[0].children
      );
    },
  },
  computed: {
    // 从 vuex 获取配置信息
    getThemeConfig() {
      return this.$store.state.themeConfig.themeConfig;
    },
  },
  mounted() {
    this.initRouteList(this.$route.path);
  },
  // 监听路由的变化
  watch: {
    $route: {
      handler(newVal) {
        this.initRouteList(newVal.path);
      },
      deep: true,
    },
  },
};
</script>

<style lang="less" scoped>
.layout-navbars-breadcrumb {
  height: inherit;
  display: flex;
  flex: 1;
  align-items: center;
  padding-left: 15px;
  .layout-navbars-breadcrumb-icon {
    cursor: pointer;
    font-size: 18px;
    margin-right: 15px;
    color: #606266;
  }
}
</style>