<template>
  <div class="layout-search-dialog" @click="openSearch">
    <el-dialog
      :visible.sync="isShowSearch"
      destroy-on-close
      :modal="false"
      fullscreen
      :show-close="false"
    >
      <el-autocomplete
        v-model="val"
        :placeholder="message_searchPlaceholder"
        :fetch-suggestions="menuSearch"
        prefix-icon="el-icon-search"
        :highlight-first-item="true"
        ref="search"
        @blur="onSearchBlur"
        @select="onSelectHandle"
      >
      </el-autocomplete>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isShowSearch: false,
      message_searchPlaceholder: "菜单搜索",
      restaurants: [],
      val: "",
      timeout: null,
    };
  },
  methods: {
    // 搜索弹窗打开
    openSearch() {
      this.isShowSearch = true;
      this.$nextTick(() => {
        this.$refs.search.focus();
      });
    },
    // input 失去焦点时搜索弹窗关闭
    onSearchBlur() {
      setTimeout(() => {
        this.isShowSearch = false;
      }, 150);
    },
    createStateFilter(queryString) {
      return (state) => {
        return (
          state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0
        );
      };
    },
    menuSearch(queryString, cb) {
      let restaurants = this.restaurants;
      let results = queryString
        ? restaurants.filter(this.createStateFilter(queryString))
        : restaurants;
      clearTimeout(this.timeout);
      this.timeout = setTimeout(() => {
        cb(results);
      }, 1000 * Math.random());
    },
    loadAll() {
      return [
        { value: "三全鲜食（北新泾店）", address: "长宁区新渔路144号" },
        {
          value: "Hot honey 首尔炸鸡（仙霞路）",
          address: "上海市长宁区淞虹路661号",
        },
        {
          value: "新旺角茶餐厅",
          address: "上海市普陀区真北路988号创邑金沙谷6号楼113",
        },
        { value: "泷千家(天山西路店)", address: "天山西路438号" },
        {
          value: "胖仙女纸杯蛋糕（上海凌空店）",
          address: "上海市长宁区金钟路968号1幢18号楼一层商铺18-101",
        },
        { value: "贡茶", address: "上海市长宁区金钟路633号" },
        {
          value: "豪大大香鸡排超级奶爸",
          address: "上海市嘉定区曹安公路曹安路1685号",
        },
        {
          value: "茶芝兰（奶茶，手抓饼）",
          address: "上海市普陀区同普路1435号",
        },
        { value: "十二泷町", address: "上海市北翟路1444弄81号B幢-107" },
        { value: "星移浓缩咖啡", address: "上海市嘉定区新郁路817号" },
        { value: "动力鸡车", address: "长宁区仙霞西路299弄3号101B" },
        { value: "浏阳蒸菜", address: "天山西路430号" },
        { value: "四海游龙（天山西路店）", address: "上海市长宁区天山西路" },
        {
          value: "樱花食堂（凌空店）",
          address: "上海市长宁区金钟路968号15楼15-105室",
        },
        { value: "壹分米客家传统调制米粉(天山店)", address: "天山西路428号" },
        {
          value: "福荣祥烧腊（平溪路店）",
          address: "上海市长宁区协和路福泉路255弄57-73号",
        },
        {
          value: "速记黄焖鸡米饭",
          address: "上海市长宁区北新泾街道金钟路180号1层01号摊位",
        },
        { value: "红辣椒麻辣烫", address: "上海市长宁区天山西路492号" },
        {
          value: "(小杨生煎)西郊百联餐厅",
          address: "长宁区仙霞西路88号百联2楼",
        },
        { value: "阳阳麻辣烫", address: "天山西路389号" },
        {
          value: "南拳妈妈龙虾盖浇饭",
          address: "普陀区金沙江路1699号鑫乐惠美食广场A13",
        },
      ];
    },
    onSelectHandle(a) {
      console.log(a);
    },
  },
  mounted() {
    this.restaurants = this.loadAll();
  },
};
</script>

<style lang="less" scoped>
.layout-search-dialog {
  /deep/ .el-dialog {
    box-shadow: unset !important;
    background: rgba(0, 0, 0, 0.5);
  }
  /deep/ .el-autocomplete {
    width: 560px;
    position: absolute;
    top: 100px;
    left: 50%;
    transform: translateX(-50%);
  }
}
</style>