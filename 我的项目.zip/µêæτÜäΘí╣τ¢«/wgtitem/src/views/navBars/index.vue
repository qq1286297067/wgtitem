<template>
  <div class="layout-navbars-container">
    <BreadcrumbBox />
    <div class="layout-navbars-tagsview"></div>
  </div>
</template>

<script>
import BreadcrumbBox from "./breadcrumb/index.vue";
export default {
  name: "layoutNavBars",
  data() {
    return {};
  },
  components: { BreadcrumbBox },
};
</script>

<style lang="less" scoped>
.layout-navbars-container {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
}
</style>