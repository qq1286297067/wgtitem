<template>
  <div class="pagination">
    <ul>
      <li class="prev" @click="prevPage"></li>
      <li
        :class="curPage == item ? 'active' : 'number'"
        v-for="(item, index) in pages"
        :key="index"
        @click="handlePage(item)"
      >
        {{ item }}
      </li>
      <li class="next" @click="nextPage"></li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "my-pagination",
  props: {
    pageSize: {
      //每页显示数量
      type: Number,
      default: 0,
    },
    totals: {
      //总数
      type: Number,
      default: 0,
    },
    page: {
      // 当前页
      type: Number,
      default: 1,
    },
  },
  data() {
    return {
      itemArr: [], //显示页数
      defaultPage: 1, //默认页数
      curPage: 1,
      size: this.pageSize, //获取每页数量
    };
  },
  methods: {
    handlePage(item) {
      if (item === "...") {//点击...不起作用
        return;
      }
      if (item === this.curPage) {//点击当前页不起作用
        return;
      }
      sessionStorage.setItem("pagination_pageNo", item);
      this.curPage = item;
      this.$emit("size-change", this.curPage);
    },
    prevPage() { //上一页
      if (this.curPage > 1) {
        this.curPage = --this.curPage;
        this.$emit("size-change", this.curPage);
      }
    },
    nextPage() { //下一页
      if (this.curPage < this.pageTotal) {
        this.curPage = ++this.curPage;
        this.$emit("size-change", this.curPage);
      }
    },
  },
  computed: {
    pageNum() {
      // 由于父组件传递过来的属性，子组件的钩子里面不能直接使用，用计算属性代替接收
      return this.pageSize;
    },
    pageItems() {
      return this.totals;
    },
    pageTotal() {
      return Math.ceil(this.pageItems / this.pageNum);
    },
    pages() {
      let pageTotal = this.pageTotal;
      let pageNo = this.curPage;
      if (!pageTotal) return [1];
      if (pageTotal < 10) {
        return pageTotal;
      } else if (pageNo < 5) {
        return [1, 2, 3, 4, 5, "...", pageTotal];
      } else if (pageNo > pageTotal - 4) {
        return [
          1,
          "...",
          pageTotal - 4,
          pageTotal - 3,
          pageTotal - 2,
          pageTotal - 1,
          pageTotal,
        ];
      } else {
        return [1, "...", pageNo - 1, pageNo, pageNo + 1, "...", pageTotal];
      }
    },
  },
  created() {
    this.curPage = parseInt(sessionStorage.getItem("pagination_pageNo")) || 1;
  },
  beforeDestroy() {
    setTimeout(() => {
      sessionStorage.removeItem("pagination_pageNo");
    }, 15000 );
  },
};
</script>

<style>
.pagination {
  overflow: hidden;
}
.pagination ul {
  user-select: none; /* 不能选择文本 */
  text-align: center;
}
.pagination ul li {
  box-sizing: border-box;
  display: inline-block;
  width: 30px;
  height: 30px;
  text-align: center;
  line-height: 30px;
  /* cursor: pointer; */
  margin: 0 3px;
  border-radius: 2px;
  background-color: rgb(244, 244, 245);
  font-size: 13px;
  font-weight: 700;
  color: rgb(96, 98, 102);
  transition: color 0.5;
}
.pagination ul li:hover.number {
  color: #409eff;
  cursor: pointer;
}
.pagination ul li.active {
  background-color: #409eff;
  color: #fff;
  cursor: default;
}
.pagination ul li.prev::before {
  content: "<";
  height: 100%;
  vertical-align: top;
}
.pagination ul li.next::before {
  content: ">";
  height: 100%;
  vertical-align: top;
}
.pagination ul li.prev.disable,
li.next.disable {
  cursor: not-allowed;
}
</style>