请先安装mysql数据库

```js
// 导入数据库文件中的item.sql



// 服务端的数据库info(创建数据库请按照这个来)
const pool = mysql.createPool({
    host: 'localhost',
    port: 3306,
    database: 'item',
    user: 'root',
    password: '123456'
});
```



`Koa_server` 

npm install 一下



`wgtitem`

npm install 一下