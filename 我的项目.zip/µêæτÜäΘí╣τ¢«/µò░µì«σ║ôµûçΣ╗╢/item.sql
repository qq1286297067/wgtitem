/*
 Navicat Premium Data Transfer

 Source Server         : MySQL
 Source Server Type    : MySQL
 Source Server Version : 80016
 Source Host           : localhost:3306
 Source Schema         : item

 Target Server Type    : MySQL
 Target Server Version : 80016
 File Encoding         : 65001

 Date: 30/08/2021 18:51:16
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `power` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
BEGIN;
INSERT INTO `user` VALUES ('admin', '123456', '管理员1', '管理员', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('root', '123456', '管理员2', '管理员', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('admin1', '123456', '管理员3-1', '设备管理员', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('admin2', '123456', '管理员3-2', '设备管理员', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('G4975557', '123456', '赢赢赢赢', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user2', '123456', '用户2', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user3', '123456', '用户3', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user4', '123456', '用户4', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user5', '123456', '用户5', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user6', '123456', '用户6', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user7', '123456', '用户7', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '用户8', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '最终用户1', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '最终用户2', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('user8', '123456', '最终用户3', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
INSERT INTO `user` VALUES ('G4975557', '123456', '最终用户4', '用户', 'http://127.0.0.1:3000/static/images/fgo.jpg');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
